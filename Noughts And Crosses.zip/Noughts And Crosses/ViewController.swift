//
//  ViewController.swift
//  Noughts And Crosses
//
//  Created by Hemang on 11/05/20.
//  Copyright © 2020 Hemang. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var activePlayer = 1 //crosses
    var gamestate = [0,0,0,0,0,0,0,0,0] //initial state
    var gameisactive = true //activity
    var end = false
    
    //down is winning combinations
    
    let wincombination = [[0,1,2], [3,4,5], [6,7,8], [0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]]
    
    
    @IBOutlet weak var label: UILabel!
    
    @IBAction func action(_ sender: AnyObject)
    {
        
        if (gamestate[sender.tag-1] == 0 && gameisactive == true)
        {
            gamestate[sender.tag-1] = activePlayer
            
            if(activePlayer == 1){
                sender.setImage(UIImage(named : "Crosses.001.png"), for: UIControl.State())
                activePlayer = 2
            }
            
            else
            {
                sender.setImage(UIImage(named : "Noughts.001.png"), for: UIControl.State())
                activePlayer = 1
            }
        }
        
        for combination in wincombination
        {
            if (gamestate[combination[0]] != 0 && gamestate[combination[0]] == gamestate[combination[1]] && gamestate[combination[1]] == gamestate[combination[2]])
            {
                gameisactive = false
                
                if gamestate[combination[0]] == 1{
                    label.text = "CROSS WINS"
                    
                }
                else
                {
                     label.text = "NOUGHTS WINS"
                     
                }
                
                label.isHidden = false
            }
            
        }
        
        gameisactive = false
        
        for i in gamestate
        {
           if i == 0
            {
                
                gameisactive = true
                break
                
            }
        }
        
        
        if gameisactive == false
        {
            label.text = "IT'S A DRAW"
            label.isHidden = false
        }
    }
    
    @IBAction func playagain(_ sender: AnyObject) {
        gamestate = [0,0,0,0,0,0,0,0,0]
        gameisactive = true
        activePlayer = 1
        label.isHidden = true
        
        for i in 1...9
        {
            let button = view.viewWithTag(i) as! UIButton
            button.setImage(nil, for: UIControl.State())
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

